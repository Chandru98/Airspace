<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('trail_details');
    // return view('welcome');
});

//Get Trail Details
Route::get('trail/{id}', 'App\Http\Controllers\TrailController@get_trail')->where('id', '[0-9]+');

Route::get('trail_item/{id}', 'App\Http\Controllers\TrailController@get_trail_item')->where('id', '[0-9]+');
Route::post('update_trail_item/{id}', 'App\Http\Controllers\TrailController@update_trail_item')->where('id', '[0-9]+');

Route::get('trail_details', 'App\Http\Controllers\TrailController@trail_details');
Route::get('add_trail', 'App\Http\Controllers\TrailController@add_trail');
Route::post('update_trail', 'App\Http\Controllers\TrailController@update_trail');



