<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="{{url('css/common.css')}}" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" type="text/css">
    <title>Trail Detail</title>
  </head>
  <body>
    <section class="container">
      <div class="trail-table-outer-wrap">
        <h2>{{$section == 'trail' ? 'Trail With Trail Item Details' : 'Trail Item'}}</h2>
        @if($error)
        <div>
          <h3>{{$msg}}</h3>
        </div>
        @else
          @if(Session::has('message'))
          <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}<i class="fa fa-close" onclick="this.parentElement.style.display='none';"></i></p>
          @endif   

          @if($section == 'trail')
          <div class="trail-table">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">Id</th>
                  <th scope="col">Customer Id</th>
                  <th scope="col">Trail To</th>
                  <th scope="col">Flying From</th>
                  <th scope="col">Total Cost</th>
                  <th scope="col">Trail Items</th>
                  <!-- <th scope="col">Action</th> -->
                </tr>
              </thead>
              <tbody>
                @if($trail_details)
                <tr>
                  <th scope="row">{{ $trail_details->id }}</th>
                  <td>{{ $trail_details->customer_id }}</td>
                  <td>{{ $trail_details->trail_to }}</td>
                  <td>{{ $trail_details->flying_from }}</td>
                  <td>{{ $trail_details->total_cost }}</td>
                  <td>
                    @if($trail_details->trail_items)
                      @if(count($trail_details->trail_items) > 0)
                      <table>
                        <thead>
                          <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Trail Id</th>
                            <th scope="col">Date</th>
                            <th scope="col">Cost</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach($trail_details->trail_items as $k1 => $v1)
                          <tr>
                            <td>{{ $v1['id'] }}</td>
                            <td>{{ $v1['trail_id'] }}</td>
                            <td>{{ $v1['date'] }}</td>
                            <td>{{ $v1['cost'] }}</td>
                            <td>
                              <a href="{{url('trail_item/'.@$v1['id'])}}" class="open_dialog" data-id="{{ $v1['id'] }}">
                                <i class="fa fa-pencil" aria-hidden="true" ></i>
                              </a>
                            </td>
                          </tr>
                          @endforeach
                        </tbody>
                      </table>
                      @endif
                      @if(count($trail_details->trail_items) <= 0)                      
                      -
                      @endif
                    @endif
                  </td>
                  <!-- <td>
                    <a href="#" data-toggle="modal" data-target="#cost_update_modal"><i class="fa fa-pencil"></i></a>
                  </td> -->
                </tr>
                @endif
              </tbody>
            </table>
            @endif
          </div>
          @if($section == 'trail_item')

          <div class="edit_trail_item_details">       
            <form method="post" action="{{url('update_trail_item/'.@$trail_item_details->id)}}">
              @csrf
              <div class="form-group mb-3">
                <label for="trail_item_id">Id</label>
                <input type="text" class="form-control" id="trail_item_id" value="{{@$trail_item_details->id}}" readonly="">
              </div>
              <div class="form-group mb-3">
                <label for="trail_id">Trail ID</label>
                <input type="text" class="form-control" id="trail_id" value="{{@$trail_item_details->trail_id}}" readonly="">
              </div>
              <div class="form-group mb-3">
                <label for="date">Date</label>
                <input type="text" class="form-control" id="date" value="{{@$trail_item_details->date}}" readonly="">
              </div>
              <div class="form-group mb-3">
                <label class="form-check-label" for="cost">Cost</label>
                <input type="number" class="form-control" id="cost" value="{{ old('cost') ? old('cost') : @$trail_item_details->cost}}" placeholder="Enter Your Cost" min="1" name="cost">
                @if($errors->has('cost'))
                <span class="text-danger">
                    {{ $errors->first('cost') }}
                </span>              
                @endif
              </div>
              <div>
                <button type="submit" class="btn btn-success">Submit</button>
                <a href="{{url('trail/'.@$trail_item_details->trail_id)}}" class="btn btn-danger">Back</a>
              </div>
            </form>
          </div>
          @endif
        @endif
        @if($section == 'trail')
        <a href="{{url('trail_details')}}" class="btn btn-danger" style="float: right;">Back</a>
        @endif
      </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    
    <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script> -->
    
    <script type="text/javascript">
      $(document).ready(function () {
          $('#hdn_trail_item_id').val('');
          $(".open_dialog").click(function () {
              $('#hdn_trail_item_id').val($(this).data('id'));
          });
      });      
    </script>

  </body>
</html>