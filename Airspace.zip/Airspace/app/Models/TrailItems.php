<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrailItems extends Model
{
    use HasFactory;

    protected $table = 'trail_items';
    public $timestamps = false;


    public function trail(){
        return $this->belongsTo('App\Models\Trail', 'trail_id', 'id');
    }

}
