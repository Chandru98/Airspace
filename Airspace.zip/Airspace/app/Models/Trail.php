<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Trail extends Model
{
    use HasFactory;

    protected $table = 'trail';

    protected $fillable = ['id','customer_id','trail_to','flying_from','total_cost'];

    public function trail_items(){
        return $this->hasMany('App\Models\TrailItems','trail_id','id');
    }

}
