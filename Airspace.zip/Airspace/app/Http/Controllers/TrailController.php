<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trail;
use App\Models\TrailItems;
use Session;
use Validator;

class TrailController extends Controller
{
    //
    public function get_trail(Request $request){
        $key = $request->id;
        
        $data['error'] = false;
        $data['msg'] = '';

        $data['trail_details'] = [];
        $data['section'] = "trail";

        $trail = Trail::where('id',$key)->first();
        
        if(!$trail){
            $data['error'] = true;  
            $data['msg'] = "Trail ID Not Found.";
        }

        if($trail){
          // $data['trail_details'] = $trail->with('trail_items')->get();
          $data['trail_details'] = $trail;
        }
        // dd($data);

        return view('trail_detail',$data);
    }

    public function get_trail_item(Request $request){

        $key = $request->id;

        $data['error'] = false;
        $data['msg'] = '';

        $data['trail_item_details'] = [];
        $data['section'] = "trail_item";        

        $trail_item = TrailItems::find($key);
        
        if(!$trail_item){
            $data['error'] = true; 
            $data['msg'] = "Trail Item ID Not Found.";             
        }

        if($trail_item){
          $data['trail_item_details'] = $trail_item;
        }

        return view('trail_detail',$data);
    }
    public function update_trail_item(Request $request){

        $key = $request->id;
        
        $data['error'] = false;
        $data['msg'] = '';

        $data['section'] = "trail_item";

        $request->validate([
            'cost' => 'required',
        ]);

        $trail_item = TrailItems::find($key);

        if(!$trail_item){
            Session::flash('message', 'Some Error has occured'); 
            Session::flash('alert-class', 'alert-danger');             
            return back()->withInput();
        }

        $trail_item->cost = @$request->cost;
        $trail_item->save();

        // $trail_details = $trail_item->trail;
        $trail_id = $trail_item->trail_id;
        $trail = Trail::find($trail_id);
        $total_cost = $trail->trail_items->sum('cost');
        $trail->total_cost = @$total_cost;
        $trail->save();

        Session::flash('message', 'Trail Item Details Updated Successfully.'); 
        Session::flash('alert-class', 'alert-success');

        return redirect('trail/'.@$trail->id);
    }
    public function trail_details(Request $request){
        $data['section'] = 'trail_details';
        $data['trail_details'] = Trail::get();
        return view('new_trail_detail',$data);
    }

    public function add_trail(Request $request){
        $data['section'] = 'create_trail';
        return view('new_trail_detail',$data);
    }

    public function update_trail(Request $request){
        $data['section'] = 'create_trail';
        $data = $request->all();
        $recent_trail = Trail::latest()->first();
        if(!$recent_trail)
            $data['id'] = 20491;
        if($recent_trail)
            $data['id'] = @$recent_trail->id + 1;
        Trail::create($data);
        Session::flash('message', 'Trail Details Added Successfully.'); 
        Session::flash('alert-class', 'alert-success');

        return redirect('trail_details');        

    }        
}
